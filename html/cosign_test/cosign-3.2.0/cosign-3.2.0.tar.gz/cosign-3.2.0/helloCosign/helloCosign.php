<html>
    <head>
        <title>hello, cosign ( php )</title>
    </head>

    <body>
        <h1>
            Hello, <?php echo( $_SERVER[ REMOTE_USER ] ) ?>!
        </h1>
    </body>
</html>
