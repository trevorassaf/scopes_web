/*
 * Copyright (c) 2006 Regents of The University of Michigan.
 * All Rights Reserved.  See LICENSE.
 */

int	execfactor( struct factorlist *, struct cgi_list *, char ** );
