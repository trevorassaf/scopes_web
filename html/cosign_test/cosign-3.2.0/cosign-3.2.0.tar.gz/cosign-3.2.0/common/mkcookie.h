/*
 * Copyright (c) 2005 Regents of The University of Michigan.
 * All Rights Reserved.  See COPYRIGHT.
 */

int mkcookie( int, char * );
int mkcookiepath( char *, int, char *, char *, int );
int validchars( char * );
int validuser( char * );

#define MAXCOOKIELEN    1024

