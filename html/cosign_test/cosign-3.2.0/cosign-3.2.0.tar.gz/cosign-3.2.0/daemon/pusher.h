int pusherparent ( int );
int pusherhosts ( void );
