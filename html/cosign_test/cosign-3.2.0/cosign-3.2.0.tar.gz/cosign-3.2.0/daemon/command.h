/*
 * Copyright (c) 1998 Regents of The University of Michigan.
 * All Rights Reserved.  See LICENSE.
 */

extern int	tlsopt;

int		command( int, SNET * );
int		argcargv( char *, char **[] );
